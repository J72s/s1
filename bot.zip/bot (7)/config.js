module.exports = {
    token: "",
    prefix: "",
};

/* remove .example from the name of this file */